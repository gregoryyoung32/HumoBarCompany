This folder is reserved for image assets.

The current site design uses no raster images — all visuals are built with
CSS gradients, borders, and typography (the "smoke" aesthetic, icons like
☑ ◈ ✦, etc.) so the site loads fast with zero image requests.

If you want to add real photography (bar setups, cocktails, event photos),
drop files here and reference them in index.html like:

  <img src="images/your-photo.jpg" alt="Description">

or in css/styles.css like:

  background-image: url('../images/your-photo.jpg');
